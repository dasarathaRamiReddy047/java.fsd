package com.camera;

import java.util.*;

import java.util.ArrayList;

class camera {

	// Default Camera Details
	double CurrentBalance = 2000.0;

	int[] cameraIds = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
	String[] cameraNames = { "Canon", "Nikon", "Sony", "Fujifilm", "Olympus", "Panasonic", "Leica", "Pentax",
			"Hasselblad", "Phase One", "Ricoh", "Sigma", "GoPro", "DJI", "Kodak", "Yashica", "Hoya", "Minolta", "Zeiss",
			"Lomography" };
	String[] cameraModels = { "EOS", "D850", "Alpha", "X-T4", "OM-D E-M1 Mark III", "Lumix S1R", "SL2", "K-1 II",
			"X1D II 50C", "IQ4 150MP", "GR III", "fp", "HERO9 Black", "Mavic Air 2", "PIXPRO AZ901", "Electro 35",
			"Pentax Spotmatic", "Maxxum 7000", "Batis", "Lomo LC-A+" };

	double[] cameraPrice = { 500.0, 600.0, 500.0, 1000.0, 800.0, 500.0, 600.0, 500.0, 1000.0, 800.0, 1200.0, 1100.0,
			900.0, 600.0, 1000.0, 800.0, 500.0, 600.0, 500.0, 1000.0 };

	String[] cameraAvailability = {

			"Available", "Available", "Rented", "Available", "Available", "Rented", "Available", "Available", "Rented",
			"Available", "Available", "Rented", "Available", "Rented", "Available", "Available", "Rented", "Available",
			"Available", "Rented" };

	ArrayList<Integer> id = new ArrayList<>();
	ArrayList<String> brand = new ArrayList<>();
	ArrayList<String> model = new ArrayList<>();
	ArrayList<Double> price = new ArrayList<>();
	ArrayList<String> status = new ArrayList<>();

	public void welcome() {
		System.out.println("+----------------------------------+");
		System.out.println("| Welcome TO Camera Rental App     |");
		System.out.println("+----------------------------------+");
	}

	public void Login() {
		System.out.println("PLEASE LOGIN TO CONTINUE");
		System.out.println("USERNAME: ");
		String username = input.nextLine();
		System.out.println("PASSWORD: ");
		String password = input.nextLine();

	}

	public void options() {
		System.out.println();
		System.out.println(" 1)MY CAMERA \n 2) RENT A CAMERA \n 3) VIEW ALL CAMERAS \n 4) MY WALLET \n 5) EXIT ");
		System.out.println();

	}

	// displays default cameras
	void DefaultCameraDetails() {
		System.out.println("+" + "-".repeat(100) + "+");
		System.out.printf("|%10s |%25s |%25s |%15s | %15s |%n", "CAMERA ID", "BRAND", "MODEL", "PRICE(PER DAY)",
				"STATUS");
		System.out.println("+" + "-".repeat(100) + "+");
		for (int i = 0; i < cameraIds.length; i++) {
			System.out.printf("|%10s |%25s |%25s |%15s | %15s | \n", cameraIds[i], cameraNames[i], cameraModels[i],
					cameraPrice[i], cameraAvailability[i]);
		}
		System.out.println("+" + "-".repeat(100) + "+");
	}

	// default details are adding new array list

	public void Camera() {
		for (int i = 0; i < cameraIds.length; i++) {
			id.add(cameraIds[i]);
			brand.add(cameraNames[i]);
			model.add(cameraModels[i]);
			price.add(cameraPrice[i]);
			status.add(cameraAvailability[i]);
		}
	}

	Scanner input = new Scanner(System.in);

	// adding new camera details to the list
	public void addCameras() {


 		try {
 		 
 		 System.out.println("ENTER THE CAMERA BRAND");
 		 String brandAdd = input.nextLine();
 		 brand.add(brandAdd);
 		 
 		 System.out.println("ENTER THE MODEL");
 		 String modelAdd = input.nextLine();
 		 model.add(modelAdd);
 		 
 		 System.out.println("ENTER THE PER DAY PRICE(INR)");
 		 
 		 double priceAdd = input.nextDouble();
 		 price.add(priceAdd);
 		 
 		 
 		 status.add("Avaliable");
 		 int len = id.size();
 		 id.add(len+1);
 		 
 		 System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST");
 		}catch (Exception e) {
			 System.out.println("Invalid,Please Enter Price Integers Only!");
		 }
 	 }
	    
	


	// removing user given cameras
	public void removeCamera() {

		System.out.println("ENTER THE CAMERA ID TO REMOVE");
		
		try {
		int removeId = input.nextInt();
		
		int ind = id.indexOf(removeId);
		
		if (ind != -1) {
			id.remove(ind);
			brand.remove(ind);
			model.remove(ind);
			price.remove(ind);
			status.remove(ind);
			System.out.println("CAMERA SUCCESSFULLT REMOVED FROM THE LIST");

		} else {
			System.out.println("Invalid Camera Id");
		}
		}catch(Exception e){
			System.out.println("Enter Valid Id");
		}

	}

	// displaying available cameras

	public void availableCameras() {

		System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERA(S)");
		System.out.println("+" + "-".repeat(100) + "+");
		System.out.printf("|%10s |%25s |%25s |%15s | %15s |%n", "CAMERA ID", "BRAND", "MODEL", "PRICE(PER DAY)",
				"STATUS");
		System.out.println("+" + "-".repeat(100) + "+");
		int count = 0;
		for (int i = 0; i < id.size(); i++) {
			if (status.get(i).equals("Available")) {
				count++;
				System.out.printf("|%10s |%25s |%25s |%15s | %15s | \n", id.get(i), brand.get(i), model.get(i),
						price.get(i), status.get(i));

			}
		}
		System.out.println("+" + "-".repeat(100) + "+");

		System.out.println("ENTER THE CAMERA ID YOU WANT TO RENT");

		try {
			int cameraId = input.nextInt();
			double cameraPrice = price.get(cameraId);
			int index = id.indexOf(cameraId);

			if (CurrentBalance >= cameraPrice) {

				CurrentBalance -= cameraPrice;
				status.set(index, "Rented");
				System.out.println("YOUR TRANSACTION FOR CAMERA- " + brand.get(index) + " " + model.get(index) + " "
						+ "with rent INR. " + price.get(index) + " " + "HAS SUCCESSFULLY COMPLETED.");

			} else {
				System.out.println(
						"ERROR: TRANSACTION FAILED DUE TO INSUFFICIENT WALLET BALANCE. PLEASE DEPOSIT THE AMOUNT TO YOUR WALLET.");
			}
		} catch (Exception e) {
			System.out.println("Invalid Id , try Again");
		}

	}

	// My Wallet
	public void myWallet() {

		System.out.println("YOUR CURRENT WALLET BALANCE IS - INR. " + CurrentBalance);
		System.out.println("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET?(1.YES 2.NO)");
		int addOption = input.nextInt();

		if (addOption == 1) {
			System.out.println("ENTER THE AMOUNT (INR)");
			double amount = input.nextDouble();
			CurrentBalance += amount;
		}
		System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE- INR. " + CurrentBalance);
	}

	public void myCameraOptions() {
		System.out.println(" 1) ADD \n 2) REMOVE \n 3) VIEW MY CAMERAS \n 4) GO TO PREVIOUS MENU");
	}

	public void exit() {
		System.out.println("Closing your application... \nThank you!");
	}

	// displays all cameras in the list
	public void viewAllCameras() {
		if (id.size() > 0) {

			System.out.println("+" + "-".repeat(100) + "+");
			System.out.printf("|%10s |%25s |%25s |%15s | %15s |%n", "CAMERA ID", "BRAND", "MODEL", "PRICE(PER DAY)",
					"STATUS");
			System.out.println("+" + "-".repeat(100) + "+");
			for (int i = 0; i < id.size(); i++) {
				System.out.printf("|%10s |%25s |%25s |%15s | %15s | \n", id.get(i), brand.get(i), model.get(i),
						price.get(i), status.get(i));
			}
			System.out.println("+" + "-".repeat(100) + "+");
		} else {
			System.out.println(": No Data Present at This Moment.");
		}
	}

}

class CameraRent {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		camera cam = new camera();
		cam.Camera();
		cam.welcome();
		cam.Login();

		while (true) {
			cam.options();
			System.out.println("Choose above options: ");
			int options = input.nextInt();
			switch (options) {
			case 1:
				cam.myCameraOptions();
				System.out.println("Choose above My Camera Options");
				int myoption = input.nextInt();
				switch (myoption) {
				case 1:
					cam.addCameras();
					break;
				case 2:
					cam.removeCamera();
					break;
				case 3:
					cam.viewAllCameras();
					break;
				case 4:
					System.out.println("Previous Menu");
					break;
				}
				break;
			case 2:
				cam.availableCameras();
				break;
			case 3:
				cam.viewAllCameras();
				break;
			case 4:
				cam.myWallet();
				break;
			case 5:
				cam.exit();
				System.exit(0);
				break;
			}
		}

	}

}