package com;
import java.io.*;
  
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;  
  
 @WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {  
  
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{  	 
    PrintWriter out = response.getWriter();  
    String name=request.getParameter("userName");  
    out.print("Welcome "+name);  
    Cookie cookie=new Cookie("username",name);
    response.addCookie(cookie);
    out.println(cookie);
          
  }  
}  