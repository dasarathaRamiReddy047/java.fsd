package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/login")
public class HiddenForm extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        HttpSession session = request.getSession(true);
        session.setAttribute("username", username);
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Welcome</title></head>");
        out.println("<body>");
        out.println("<h1>Welcome, " + username + "!</h1>");
        out.println("<form action='dashboard' method='post'>");
        out.println("<input type='hidden' name='sessionID' value='" + session.getId() + "'/>");
        out.println("<input type='submit' value='Go to Dashboard'/>");
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
    }
}
