package practice;
import java.util.LinkedList;
import java.util.Queue;

public class Problem9 {
	// program in Java to insert and remove elements in a queue
	
	public static void main(String[] args) {
		
		Queue <Integer> queue = new LinkedList<>();
		
		// insert
		queue.add(100);
		queue.add(200);
		queue.add(300);
		queue.add(400);
		queue.add(500);
		
		System.out.println("InsertedElements: " + queue);
		
		//remove 
		
		System.out.println("Removed Element: " + queue.remove(100));
		
		System.out.println("After Removed Elements: " + queue);
		
		
		
		
		
		
	}

}
