package practice;

import java.util.Arrays;

public class Problem2 {
	
	// to find fourth smallest element in an unsorted list 
	
	public static void main(String[] args) {
		
		int[] array = {84,45,23,5,45,54,6,452,2,63,1,8}; 
		System.out.println("unSorted List: " + Arrays.toString(array));
		
		Arrays.sort(array);
				
		for(int i = 0 ; i < array.length; i++) {
			if (i == 3) {
				System.out.println("The Fourth Smallest Element is : " + array[3]);
			}
		}
	
	}

}
