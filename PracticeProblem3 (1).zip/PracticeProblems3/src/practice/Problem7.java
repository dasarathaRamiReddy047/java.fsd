package practice;

class Node {
    int data;
    Node prev;
    Node next;

    public Node(int data) {
        this.data = data;
        prev = null;
        next = null;
    }
}

class DoublyList {
    Node head;

    public void insert(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }
    }

    public void forward() {
        if (head == null) {
            System.out.println("Doubly linked list is empty.");
            return;
        }

        System.out.print("Forward traversal: ");
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void backward() {
        if (head == null) {
            System.out.println("Doubly linked list is empty.");
            return;
        }

        System.out.print("Backward traversal: ");
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}

public class Problem7 {
    public static void main(String[] args) {
        DoublyList list = new DoublyList();
        list.insert(1);
        list.insert(2);
        list.insert(3);
        list.insert(4);

        list.forward();
        list.backward();
    }
}
