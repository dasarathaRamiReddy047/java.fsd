package practice;



public class Problem3 {
	// to find the sum of n numbers of elements in
	// the range of l and r 
	
	public static void main(String[] args) {
	

	int l = 2;
	int r = 10;

	int sum = 0;
	
	int count = 0;

	for(int i = l ; i <=r ; i++ ) {
		sum+=i;
		count += 1;
	}
	System.out.println("The n Number of elements Occurs: " + " " + count);
	System.out.println("Sum is: " + sum);
	
}
}