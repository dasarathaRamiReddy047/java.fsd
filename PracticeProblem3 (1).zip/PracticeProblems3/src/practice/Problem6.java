package practice;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        next = null;
    }
}

class CircularList {
    Node head;

    public void insert(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            head = newNode;
            head.next = head;
            return;
        }

        Node current = head;

        if (newNode.data < head.data) {
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
            return;
        }

        while (current.next != head && current.next.data < newNode.data) {
            current = current.next;
        }

        newNode.next = current.next;
        current.next = newNode;
    }

    public void displayList() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;

        System.out.print("CircularLinkedList: ");
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class Problem6 {
    public static void main(String[] args) {
        CircularList list = new CircularList();
        list.insert(1);
        list.insert(3);
        list.insert(5);
        list.insert(7);

        list.displayList();
    }
}
