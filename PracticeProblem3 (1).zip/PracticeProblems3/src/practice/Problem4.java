package practice;


import java.util.Arrays;

public class Problem4 {
	//program in Java to multiply two matrices
	public static void main(String [] args) {
		
		
		int[][] m1 = new int[2][2];
		
		m1[0][0] = 1;
		m1[0][1] = 4;
		
		m1[1][0] = 2;
		m1[1][1] = 3;
		
		

		int[][] m2 = new int[2][2];
		
		m2[0][0] = 5;
		m2[0][1] = 7;
		
		m2[1][0] = 6;
		m2[1][1] = 9;
		
		System.out.println("First Matrix: " + Arrays.toString(m1[0]) + " " + Arrays.toString(m1[1]));
		System.out.println("Second Matrix: " + Arrays.toString(m2[0]) + " " + Arrays.toString(m2[1]));
		
		
		int[][] multipied_martrix = new int[2][2];
		
		
		
		
		for(int i = 0;i<m1.length; i++) {
			
			for(int j = 0; j<m2.length; j++) {
				int mul = m1[i][j] * m2[i][j];
				multipied_martrix[i][j] = mul;
			}
		}
	
		
		System.out.println("Multipied Matrix:  " + Arrays.toString(multipied_martrix[0])+""+Arrays.toString(multipied_martrix[1]));
		
		
	}

}
