package practice;

import java.util.Stack;

public class Problem8 {
	//program in Java to insert and remove elements in a stack
	
	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<>();
		
	// Insert	
		stack.push(2);
		stack.push(10);
		stack.push(100);
		stack.push(200);
		
	System.out.println("Inserted :" + stack);	
	
	// remove 
	
	System.out.println("removed element: " + stack.pop());
	System.out.println("After removing element: " + stack);

	}

}
