package practice;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Rotate {
	public static void main(String[] args) {
		int[] arr = {2,17,6,9,12,24};
		int steps = 5;
		int a =arr.length;
		
		System.out.println("Original: " + " " +Arrays.toString(arr));
		
		List<Integer> list = new LinkedList<>();
		
		if (steps>a) {
			steps = steps % 2;
		}
		for(int i = 0 ; i <steps; i++) {
		
			list.add(arr[a-steps+i]);
		}
		
	
		
		for(int j = 0 ; j < (a-steps); j++){
		
			list.add(arr[j]);
		}
		
		System.out.println("AFter steps :" + " " + list);
		}
	

}
