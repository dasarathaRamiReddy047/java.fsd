package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateLazyCollectionExample {
    public static void main(String[] args) {
        // Create Hibernate SessionFactory
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

        // Create a new post
        Post post = new Post();
        post.setTitle("Sample Post");

        // Create new comments
        Comment comment1 = new Comment();
        comment1.setText("Comment 1");
        Comment comment2 = new Comment();
        comment2.setText("Comment 2");

        // Associate comments with the post
        post.getComments().add(comment1);
        post.getComments().add(comment2);

        // Set post for comments
        comment1.setPost(post);
        comment2.setPost(post);

        // Save the post and comments
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        session.save(post);

        transaction.commit();
        session.close();

        // Retrieve the post and lazily load the comments
        session = sessionFactory.openSession();
        Post retrievedPost = session.get(Post.class, post.getId());
        session.close();

        // Access the comments, which will trigger lazy loading
        System.out.println("Post: " + retrievedPost.getTitle());
        System.out.println("Comments:");
        for (Comment comment : retrievedPost.getComments()) {
            System.out.println(comment.getText());
        }

        // Close the SessionFactory
        sessionFactory.close();
    }
}
