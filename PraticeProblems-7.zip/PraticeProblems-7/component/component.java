package mapping;

public class component {

    public static void main(String[] args) {
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();

        Transaction transaction = session.beginTransaction();

        // Create an address
        Address address = new Address();
        address.setStreet("123 Main Street");
        address.setCity("City");
        address.setState("State");
        address.setZipCode("12345");

        // Create an employee with the address
        Employee employee = new Employee();
        employee.setName("John Doe");
        employee.setAddress(address);

        // Persist the employee
        session.persist(employee);

        transaction.commit();

        session.close();
        sessionFactory.close();
    }
}

