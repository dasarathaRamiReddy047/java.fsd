package mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class mapping {
    public static void main(String[] args) {
        // Configure Hibernate
        Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();

        Transaction transaction = session.beginTransaction();

        // Create a Person object with addresses
        Person person = new Person();
        person.setName("John Doe");

        // Create Address objects
        Address address1 = new Address();
        address1.setStreet("Street 1");
        address1.setCity("City 1");

        Address address2 = new Address();
        address2.setStreet("Street 2");
        address2.setCity("City 2");

        Address address3 = new Address();
        address3.setStreet("Street 3");
        address3.setCity("City 3");

        // List mapping
        List<Address> addressList = new ArrayList<>();
        addressList.add(address1);
        addressList.add(address2);
        person.setAddresses(addressList);

        // Set mapping
        Set<Address> addressSet = new HashSet<>();
        addressSet.add(address1);
        addressSet.add(address2);
        person.setAddresses(addressSet);

        // Bag mapping
        Bag<Address> addressBag = new Bag<>();
        addressBag.add(address1);
        addressBag.add(address2);
        person.setAddresses(addressBag);

        // Map mapping
        Map<String, Address> addressMap = new HashMap<>();
        addressMap.put("Home", address1);
        addressMap.put("Work", address2);
        person.setAddresses(addressMap);

        // Save the person object
        session.save(person);

        transaction.commit();
        session.close();
        sessionFactory.close();
    }
}
