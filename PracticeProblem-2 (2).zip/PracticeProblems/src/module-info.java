/**
 * 
 */
/**
 * @author dasar
 *
 */
module PracticeProblems {
}