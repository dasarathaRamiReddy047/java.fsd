package PracticeProblems;

import java.util.*;

class Counter {
    private int count = 0;

		  public synchronized void increment() {
		    count++;
		  }

		  public synchronized int getCount() {
		    return count;
		  }
		}

		class IncrementThread extends Thread {
		  private Counter counter;
		  private int numIncrements;

		  public IncrementThread(Counter counter, int numIncrements) {
		    this.counter = counter;
		    this.numIncrements = numIncrements;
		  }

		  public void run() {
		    for (int i = 0; i < numIncrements; i++) {
		      counter.increment();
		    }
		  }
		}

		public class Synchronization {
		  public static void main(String[] args) throws InterruptedException {
		    Counter counter = new Counter();
		    IncrementThread thread1 = new IncrementThread(counter, 100000);
		    IncrementThread thread2 = new IncrementThread(counter, 100000);

		    thread1.start();
		    thread2.start();

		    thread1.join();
		    thread2.join();

		    System.out.println("Final count: " + counter.getCount());
		  }
		}
