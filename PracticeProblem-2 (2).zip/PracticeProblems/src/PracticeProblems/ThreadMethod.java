package PracticeProblems;

public class ThreadMethod implements Runnable {

	public void run() {
		System.out.println("Thread is Implements Of Runnable");
	}

	public static void main(String[] args) {
		ThreadMethod obj = new ThreadMethod();
		Thread thread = new Thread(obj);
		thread.start();
	}

}
