package PracticeProblems;

import java.util.*;

public class SleepWait {
	private static Object obj = new Object();

	public static void main(String[] args) {
		try {
			Thread.sleep(2000);
			System.out.println(Thread.currentThread().getName() + "Thread is woken after two seconds");
		} catch (InterruptedException e) {
			System.out.println(e);
		}

		synchronized (obj) {
			try {
				obj.wait(2000);
				System.out.println(obj + "Object is waiting state and woken after 2 seconds");
			} catch (InterruptedException e) {
				System.out.println(e);
			}

		}
	}

}
