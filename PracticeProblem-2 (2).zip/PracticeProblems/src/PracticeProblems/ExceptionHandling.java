package PracticeProblems;

public class ExceptionHandling {

	public static void main(String[] args) {
		try {
			int num = 10 / 0;
			System.out.println("output" + num);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
