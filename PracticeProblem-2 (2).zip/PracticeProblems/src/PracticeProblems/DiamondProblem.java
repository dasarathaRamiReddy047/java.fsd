package PracticeProblems;

	
interface Interface1 {
	public static int num = 5;
	public default void display(){
		System.out.println("Interface1");
	}
}

interface Interface2{
	public static int num = 10;
	public default void display() {
		System.out.println("Interface2");
	}
}

class DiamondProblem implements Interface1, Interface2{
	public void display() {
		Interface1.super.display();
		Interface2.super.display();
		System.out.println(Interface1.num);
	}
	public static void main(String args []) {
		DiamondProblem obj = new DiamondProblem();
		obj.display();
		
	}
}