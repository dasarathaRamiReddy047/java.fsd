package PracticeProblems;


class Person {

private String name;
private int age;

// Constructor 
public Person(String name, int age) {
 this.name = name;
 this.age = age;
}


public String getName() {
 return name;
}

public int getAge() {
 return age;
}

// Abstraction: 
public void printDetails() {
 System.out.println("Name: " + name);
 System.out.println("Age: " + age);
}
}

//Inheritance: 
class Student extends Person {

private String grade;


public Student(String name, int age, String grade) {
 super(name, age);
 this.grade = grade;
}

// Polymorphism: 
@Override
public void printDetails() {
 System.out.println("Name: " + getName());
 System.out.println("Age: " + getAge());
 System.out.println("Grade: " + grade);
}
}


public class Ooprog {
public static void main(String[] args) {
 
 Person person = new Person("John Doe", 25);

 
 String name = person.getName();
 int age = person.getAge();
 


 person.printDetails();


 Student student = new Student("RAm", 25, "A+");


 name = student.getName();
 age = student.getAge();



 student.printDetails();
}
}
