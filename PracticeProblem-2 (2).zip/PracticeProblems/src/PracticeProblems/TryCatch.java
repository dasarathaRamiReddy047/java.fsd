package PracticeProblems;

public class TryCatch {
	public static void main(String[] args) {

// for try 

		try {
			int divide = 8 / 2;
			System.out.println("The number is divided");
		} catch (Exception e) {
			System.out.println(e);
		}

		// for catch

		try {
			int divide = 10 / 0;
			System.out.println("The number is divided");

		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
