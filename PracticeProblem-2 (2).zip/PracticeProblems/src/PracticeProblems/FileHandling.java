package PracticeProblems;

import java.io.*;

public class FileHandling {
	public static void main(String[] args) {

		// create a file
		File file = new File("newFile.txt");

		// write a file
		try {
			FileWriter writer = new FileWriter(file);
			writer.write("Java is used as the server-side language " + "for most back-end development projects,"
					+ " including those involving big data and Android " + "development");
			writer.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		// read a file
		try {
			FileReader reader = new FileReader(file);
			BufferedReader lineReader = new BufferedReader(reader);
			String line = lineReader.readLine();
			lineReader.close();
			System.out.println(line);
		} catch (Exception e) {
			System.out.println(e);
		}
		// delete a file
		if (file.delete()) {
			System.out.println("File deleted successfully");
		} else {
			System.out.println("Failed to delete the File");
		}

	}

}