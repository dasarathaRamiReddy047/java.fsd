package PracticeProblems;

import java.lang.Thread;

public class MyThread extends Thread {
	public void run() {
		System.out.println("MyThread extends Thread");

	}

	public static void main(String[] args) {
		MyThread obj = new MyThread();
		obj.start();
	}

}
