package PracticeProblems;

class CustomException {
	static void sum() throws ArithmeticException {

		System.out.println("Inside sum function");
		throw new ArithmeticException("Error");
	}

	public static void main(String args[]) {
		try {
			sum();
		} catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("finally is always executed");
		}
	}
}
