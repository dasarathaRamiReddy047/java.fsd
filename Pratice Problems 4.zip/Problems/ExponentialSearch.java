package Problems;


import java.util.*;

public class ExponentialSearch {

	public static void main(String[] args) {

		int arr[] = {10,20,40,50,60,70,80};
		int key = 20;
		int index = expo(arr,arr.length-1,key);
		System.out.println("Orginal Array: " + Arrays.toString(arr));
		
		if(index != -1) {
			System.out.println("Index Found at: " + index);
		}else {
			System.out.println("Element not Found");
		}
		
		
		
	}
	
	static int expo(int[] arr, int end , int key) {
		if(arr[0] == key) {
			return 0;
		}
		
		int i =1;
		while(i<end && arr[i] <= key) {
			i = i *2;
		
		}
		return  binarySearch(arr, i / 2, Math.min(i, end), key);
		
	}
		
		static int binarySearch(int[] arr, int start, int end ,int key) {
			while (start <= end) {
				int mid = start + (end - start)/2;
				
				if (arr[mid] == key) {
					return mid;
				}else if(arr[mid] < key) {
					start = mid+1;
					
				}else {
					end = mid - 1;
				}
			}	return -1;
		}
	

}
