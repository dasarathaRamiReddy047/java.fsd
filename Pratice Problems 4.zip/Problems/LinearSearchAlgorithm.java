package Problems;

 

public class LinearSearchAlgorithm {
	
	
	public int linear(int[] arr,int item) {
		
		int len = arr.length;
	
		
		for (int i = 0 ; i < len ; i++) {
			if (arr[i] == item) {
				return i;
			}
		}
		return -1;
		
	}
	
	
	public static void main(String[] args) {
		
		int[] array = {10,50,30,70,80,20,80,40};
		int a = 20;
		
		LinearSearchAlgorithm search = new LinearSearchAlgorithm();
		int pos = search.linear(array,a);
		System.out.println("The item Found at : " + pos);
		
		
	}

}
