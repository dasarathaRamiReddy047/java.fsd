package Problems;

public class BinarySearch {
	

	
	public static void main(String[] args) {
	
		int arr[] = {10,20,30,40,50,60,70};
		
		int key = 60;
		
		int a = binarySearch(arr,0,arr.length-1,key);
		
		
		if (a != -1) {
			System.out.println("Element Found at " + a);
		}else {
			System.out.println("Element Not Found");
		}
		
	}
	
	
	
	static int binarySearch(int[] arr, int start, int end, int key) {
		
		int index = (start + end) / 2;
		while(start <= end) {
		
				if(key == arr[index]) {
					return index;
					
				}else if (key < arr[index]){
					end = index -1;
					
				}else {
					start = index + 1;
				}
				index = (start + end) / 2;
			}
		return -1;
		
	}

}
