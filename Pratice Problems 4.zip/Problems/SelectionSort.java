package Problems;

import java.util.Arrays;

public class SelectionSort {
	public static void main(String[] args) {
		
		int[] arr = {100,9,6,3,1,2,4,5,1};
		System.out.println("Original Array: " + Arrays.toString(arr));
		
		for(int i = 0 ; i < arr.length; i++) {
			for(int j = 0 ; j < arr.length-i-1; j++) {
				 if(arr[j]>arr[j+1]) {
					int temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
				
			}
		}
		System.out.println("Sorted Array:" + Arrays.toString(arr));
		
		
		
	}
}