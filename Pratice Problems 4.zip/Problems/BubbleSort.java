package Problems;


import java.util.Arrays;

public class BubbleSort {
	public static void main(String[] arga) {
		int[] arr = {90,40,30,60,100,50,10};
		System.out.println("Original Array: " +Arrays.toString(arr));
		
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr.length - 1 ; j++) {
				
				if(arr[j] > arr[j+1]) {
					int temp = arr[j];
					arr[j] = arr[j+1]; 
					arr[j+1] = temp;
					
				}	
			}
		}
		System.out.println("Bubble Sort Array : " + Arrays.toString(arr));
		
		
	}

}
