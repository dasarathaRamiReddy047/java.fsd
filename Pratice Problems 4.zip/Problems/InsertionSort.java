package Problems;

import java.util.Arrays;

public class InsertionSort {
	public static void main(String[] args) {
		int[] arr = {100,9,46,7,2,6,36,7,3,6};
		System.out.println("Original Array: " + Arrays.toString(arr));
		
		for(int i = 1; i < arr.length;i++) {
			
			
			int temp = arr[i];
			int j = i - 1;
			while (j > -1 && temp < arr[j]) {
				arr[j+1] = arr[j];
				arr[j] = temp;
				j--;
			}
		}
		System.out.println("After Sorted: " + Arrays.toString(arr));
	}

}
